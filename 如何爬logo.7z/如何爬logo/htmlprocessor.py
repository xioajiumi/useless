#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Site    : 
# @File    : htmlprocessor.py

# import college.College as College
import college as c
import myIO
import re
import pickle
import requests
import time
import requests
import json



data_dir = r"C:\Users\软科数据.txt"
li = []

school_type = ["综合", "理工", "师范", "农业", "林业"]
logo_pattern1 = re.compile(r'http.*png')  # 匹配logo下载url,格式png
logo_pattern2 = re.compile(r'http.*jpg')  # 匹配logo下载url，格式jpg
note_pattern = re.compile(r"""tags">.*</p>""")  # note
name_pattern = re.compile(r"""name-cn">.*</a> <div data-v-b80b4d60""")  # name_cn
name_eng_pattern = re.compile(r"""name-en">.*</a>""")  # name_eng


def html_txt():
    College=c.College
    with open(data_dir, "r", encoding="UTF-8") as f:
        college = College()
        for line in f.readlines():  # 读取文件，逐行处理
            # print(line)
            if college.is_complete== False:  # 说明有信息缺失，继续填补当前对象的数据
                pass
            else:  # 创建一个新对象，将旧对象保存在一个列表中
                li.append(college)
                college = College()
            line = line.strip()  # 删除多余空白
            if len(line) < 6:  # 是简单数据，进一步细分处理，看看是什么数据
                if "." in line:  # 说明是浮点数
                    if float(line) < 58:  # 说明是办学层次
                        college.school_level = float(line)
                    else:  # 说明是总分
                        college.total_score = float(line)
                elif line.isdigit():
                    college.rank = int(line)
                elif line in school_type:  # 说明是学校类型
                    college.type = line
                else:  # 排除掉种种可能，说明是地点
                    college.location = line
            elif len(line) > 300 and "全部" not in line:  # 说明是大块信息
                if note_pattern.search(line):
                    college.note = note_pattern.search(line).group()[6:-4]  # note
                college.name = name_pattern.search(line).group()[9:-26].strip()  # 中文名
                college.name_eng = name_eng_pattern.search(line).group()[9:-4].strip()  # 英文名
                if logo_pattern1.search(line):  # logo's url
                    college.logo = logo_pattern1.search(line).group()
                elif logo_pattern2.search(line):
                    college.logo = logo_pattern2.search(line).group()
html_txt()
file=myIO.file_writer("中国528所大学基本信息.pkl",r="wb")
pickle.dump(li,file)
file.close()
